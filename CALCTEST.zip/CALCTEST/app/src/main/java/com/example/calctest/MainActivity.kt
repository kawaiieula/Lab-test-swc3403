package com.example.calctest

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val assignmentMarks = findViewById<EditText>(R.id.assignmentMarks)
        val midtermMarks = findViewById<EditText>(R.id.midtermMarks)
        val finalExamMarks = findViewById<EditText>(R.id.finalExamMarks)
        val calculateButton = findViewById<Button>(R.id.calculateButton)
        val resetButton = findViewById<Button>(R.id.resetButton)
        val resultText = findViewById<TextView>(R.id.resultText)
        val passFailText = findViewById<TextView>(R.id.passFailText)

        calculateButton.setOnClickListener {
            val assignment = assignmentMarks.text.toString().toFloatOrNull() ?: 0f
            val midterm = midtermMarks.text.toString().toFloatOrNull() ?: 0f
            val finalExam = finalExamMarks.text.toString().toFloatOrNull() ?: 0f

            val finalGrade = (assignment ) + (midterm ) + (finalExam )

            resultText.text = "Final Grade: ${String.format("%.2f", finalGrade)}"
            passFailText.text = if (finalGrade > 50) "Pass" else "Fail"
        }

        resetButton.setOnClickListener {
            assignmentMarks.text.clear()
            midtermMarks.text.clear()
            finalExamMarks.text.clear()
            resultText.text = "The Grade is shown here."
            passFailText.text = "The Pass or Fail is shown here."
        }
    }
}
